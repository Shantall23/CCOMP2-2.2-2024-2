#include <iostream>
#include "chessGame.h"
using namespace std;

// Constructor de la clase ChessGame
ChessGame::ChessGame(sf::Color bordL_col = sf::Color::Blue, sf::Color bordD_col = sf::Color::Black)
: board(bordL_col, bordD_col)
{   
    std::cout << "queee" << std::endl;

    font.loadFromFile("Texturesa/arial.ttf");

    if (!backgroundTexture.loadFromFile("Texturesa/path_to_background_image.jpg")) {
        // Manejar el error
    }
    backgroundSprite.setTexture(backgroundTexture);

    restart();
}

// Reinicia el juego, colocando todas las piezas en sus posiciones iniciales
void ChessGame::restart(){
    selected = false;
    playerTurn = true;
    playerTurnCheck = false;
    mate = false;
    turn = 1;

    // Inicializar piezas negras
    blackPieces[0] = new PRook(false, 7);
    blackPieces[1] = new PKnight(false, 6);
    blackPieces[2] = new PBishop(false, 5);
    blackPieces[3] = new PKing(false, 4);
    blackPieces[4] = new PQueen(false, 3);
    blackPieces[5] = new PBishop(false, 2);
    blackPieces[6] = new PKnight(false, 1);
    blackPieces[7] = new PRook(false, 0);

    // Inicializar piezas blancas
    whitePieces[0] = new PRook(true, 56);
    whitePieces[1] = new PKnight(true, 57);
    whitePieces[2] = new PBishop(true, 58);
    whitePieces[3] = new PKing(true, 59);
    whitePieces[4] = new PQueen(true, 60);
    whitePieces[5] = new PBishop(true, 61);
    whitePieces[6] = new PKnight(true, 62);
    whitePieces[7] = new PRook(true, 63);

    // Inicializar peones
    for(int i=8; i<16; i++){
        whitePieces[i] = new PPawn(true, 48 + (i - 8));
        blackPieces[i] = new PPawn(false, 15 - (i - 8));
    }

    calcPossibleMoves();
}

// Actualiza la información del turno, situación, y último movimiento
void ChessGame::updateInfo(){
    // Este método puede ser modificado o eliminado según sea necesario
}

// Dibuja el estado actual del juego
void ChessGame::draw(sf::RenderTarget& target, sf::RenderStates states) const{
    target.clear(sf::Color::Black);

    // Dibuja la imagen de fondo
    target.draw(backgroundSprite); 

    int boardSize = 512;
    int xOffset = (target.getSize().x - boardSize) / 2;
    int yOffset = (target.getSize().y - boardSize) / 2;

    sf::Transform transform;
    transform.translate(xOffset, yOffset);

    // Dibuja el tablero centrado
    target.draw(board, transform); 

    // Dibuja las posibles jugadas
    if((selectedPiece != NULL) && (selected)){
        for(int i=0; i<possibleMovesSquares.size(); i++){
            target.draw(possibleMovesSquares.at(i), transform);
        }
    }

    // Dibuja las piezas
    for(int i=0; i<16; i++){
        target.draw(*whitePieces[i], transform);
        target.draw(*blackPieces[i], transform);
    }

    // Dibuja el cuadro de selección si hay una pieza seleccionada
    if (selectedPiece != NULL && selected) {
        target.draw(selectionBorder, transform);
    }
}

// Crea el cuadro de selección alrededor de la pieza seleccionada
void ChessGame::createSelectSquare(){
    sf::RectangleShape tmp;
    selectionBorder.setSize(sf::Vector2f(64, 64)); // Tamaño del cuadro
    selectionBorder.setFillColor(sf::Color::Transparent); // Sin relleno
    selectionBorder.setOutlineColor(sf::Color::Yellow); // Contorno amarillo
    selectionBorder.setOutlineThickness(-3.f); // Grosor del contorno
    int x = (selectedPiece->getPosition() % 8) * 64;
    int y = (selectedPiece->getPosition() / 8) * 64;
    selectionBorder.setPosition(x, y);
}

// Crea las posibles casillas de movimiento para la pieza seleccionada
void ChessGame::createMovesSquares(){
    if(selectedPiece == NULL)
        return;

    possibleMovesSquares.clear();

    for(int i=0; i<selectedPiece->getPossibleMoves().size(); i++){
        sf::RectangleShape tmp;
        tmp.setPosition(sf::Vector2f((selectedPiece->getPossibleMoves().at(i) % 8) * 64.f , (selectedPiece->getPossibleMoves().at(i) / 8) * 64.f));
        tmp.setSize(sf::Vector2f(64.f, 64.f));
        tmp.setFillColor(sf::Color(0x66b4cc50));
        possibleMovesSquares.push_back(tmp);
    }
    createSelectSquare();
}

// Selecciona una pieza en una posición dada
bool ChessGame::selectPiece(int pos){
    selectedPiece = NULL;
    selected = false;

    for (int i=0; i<16; i++){
        if(playerTurn){
            if (whitePieces[i]->getPosition() == pos){
                selectedPiece = whitePieces[i];
                selected = true;
                break;
            }
        } else {
            if (blackPieces[i]->getPosition() == pos){
                selectedPiece = blackPieces[i];
                selected = true;
                break;
            }
        }
        selected = false;
    }

    if (!selected){
        selectedPiece = NULL;
        possibleMovesSquares.clear();
        return selected;
    }

    createMovesSquares();
    return selected;
}

// Mueve la pieza seleccionada a una nueva posición
void ChessGame::moveSelected(int pos){
    bool validMove{false};

    if((selectedPiece == NULL) || !selected)
        return;

    for(int i=0; i<selectedPiece->getPossibleMoves().size(); i++){
        if(pos == selectedPiece->getPossibleMoves().at(i)){
            validMove = true;
            break;
        }
    }

    if(validMove){
        selectedPiece->setPosition(pos);

        for(int i=0; i<16; i++){
            if(selectedPiece->getPlayer()){
                if(blackPieces[i]->getPosition() == pos){
                    blackPieces[i]->setPosition(-1);
                    break;
                }
            } else {
                if(whitePieces[i]->getPosition() == pos){
                    whitePieces[i]->setPosition(-1);
                    break;
                }
            }
        }

        playerTurn = !playerTurn;
        calcPossibleMoves();
    }

    selectedPiece = NULL;
    selected = false;
}

// Calcula los movimientos posibles para todas las piezas
void ChessGame::calcPossibleMoves(){
    Piece* tmp;

    for (int i=0; i<32; i++){
        if (i<16)
            tmp = whitePieces[i];
        else
            tmp = blackPieces[i-16];

        tmp->getPossibleMoves().clear();

        if (tmp->getPosition() == -1){
            continue;
        }

        getPosicionesWhitePieces();
        getPosicionesBlackPieces();

        tmp->calcPiecePossibleMoves();
    }

    updateInfo();
    turn++;
}

// Obtiene las posiciones de las piezas blancas
std::array<int, 16> ChessGame::getPosicionesWhitePieces()  {
    std::array<int, 16> posiciones;
    for (std::size_t i = 0; i < 16; ++i) {
        posiciones[i] = whitePieces[i]->getPosition();
    }
    Piece::setPosiciones(posiciones);
    return posiciones;
}

// Obtiene las posiciones de las piezas negras
std::array<int, 16> ChessGame::getPosicionesBlackPieces()  {
    std::array<int, 16> bposiciones;
    for (std::size_t i = 0; i < 16; ++i) {
        bposiciones[i] = blackPieces[i]->getPosition();
    }
    Piece::setPosicionesB(bposiciones);
    return bposiciones;
}
